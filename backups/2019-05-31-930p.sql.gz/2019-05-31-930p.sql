The Drush launcher could not find a local Drush in your Drupal site.
Please add Drush with Composer to your project.
Run 'cd "/var/www/template/d8/docroot" && composer require drush/drush'
